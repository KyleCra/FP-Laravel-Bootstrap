@extends('layouts.app')

@section('title', 'Articles')

@section('content')
<h1>Articles</h1>

<div>
@foreach ($articles as $article)
  <div>Title : {{ $article->title }}</div>
@endforeach
</div>

@endsection
