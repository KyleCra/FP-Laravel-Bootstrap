@extends('templates.main')

@section('body')
    <div class="page-header p-4 pb-0 mt-4">
        <h1>List Category</h1>

        <div class="table-responsive">

        <table class="table">
        <thead>
            <tr>
                <th scope="col" width="5%">
                    <div class="form-check form-check-primary">
                        <input class="form-check-input" id="custom_mixed_parent_all" type="checkbox">
                    </div>
                </th>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">ACTION</th>
            </tr>
            <tr aria-hidden="true" class="mt-3 d-block table-row-hidden"></tr>
        </thead>
        <tbody>
            @foreach($categories as $item)
                <tr>
                    <td></td>
                    <td>{{$item->id}}</td>
                    <td>{{$item->name}}</td>

                    <td>
                        <form action="{{ route('category.destroy',$item->id) }}" method="POST">
                        <a class="btn btn-info" href="{{route('category.show',$item->id)}}">Show</a>
                        <a class="btn btn-primary" href="{{route('category.edit',$item->id)}}">Edit</a>

                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>

                </tr>
            @endforeach
        </tbody>
    </table>
    <a class="btn btn-primary" href="{{route('category.create')}}">Create Category</a>
    <br/>
	Halaman : {{ $categories->currentPage() }} <br/>
	Jumlah Data : {{ $categories->total() }} <br/>
	Data Per Halaman : {{ $categories->perPage() }} <br/>

    <br/>
	{{ $categories->links() }}
    </div>
@endsection
