@extends('layouts.app')

@section('title','Warung')

@section('content')
<div class="container-fluid MobileWrapper">
  <div class="container Mobile">
    <div class="inner-page-container">
      <div class="inner-top-auth mt-3">
        <h3>
          <img src="/logo.png" alt="" width="100px;">
          <span>Warung</span>
        </h3>
      </div>
      <div class="inner-content mt-2">
        <div>
          <div>
            <label for="">Username</label>
            <input type="text" id="username" class="form-control">
          </div>
          <div>
            <label for="">Password</label>
            <input type="password" id="password" class="form-control">
          </div>
          <div class="btn-group d-flex mt-1">
            <a href="javascript:;" class="btn btn-default-warung btn-login">Masuk</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection

@push('after-script')
<script>
  $( document ).ready(function() {
    var ajax_login = function(){
      let formData = new FormData;
      formData.append('username', $('#username').val());
      formData.append('password', $('#password').val());
      $('.btn-login').addClass('disabled');
      axios.post('/ajax/login',formData)
      .then(response => {
        if(response.data.status === 'SUCCESS'){
          location.href = response.data.redirect_url;
        }else{
          Swal.fire({
            "title":"Maaf",
            "customClass":{"container":"swal-alert-error"},
            "allowOutsideClick":false,
            "html":"<div>"+response.data.message+"<\/div>"
          });
        }
      })
      .finally(function(){
        $('.btn-login').removeClass('disabled');
      });
    };

    $('.btn-login').click(function(){
      ajax_login();
    });
    
    $('#password').keypress(function (e) {
      var key = e.which;
      if(key == 13){
        ajax_login();
        return false;  
      }
    });   
  });
</script>
@endpush