@extends('layouts.app')
@section('title', 'Home')
@section('content')

@for ($i = 0; $i < 10; $i++)
    The current value is {{ $i }} <br>
@endfor
@endsection



