@extends('layouts.app')
@section('title', 'Contact Us')
@section('content')
<h1>Contact Us</h1>
@endsection




