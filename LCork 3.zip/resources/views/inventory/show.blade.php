@extends('templates.main')

@section('body')
    <div class="page-header p-4 pb-0 mt-4">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <h2>Show Inventories</h2>
            </div>
            <div class="pull-right">
                <a href="{{route('inventory.index')}}" class="btn btn-primary">Back</a>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                <strong>Name:</strong>
                {{$inventory->name}}
                </div>
            </div>
            {{-- image --}}
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Image:</strong>
                    <img src="{{ $inventory->image }}" alt="Inventory Image">
                </div>
            </div>

            {{-- category --}}
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                <strong>Name:</strong>
                {{$category_name}}
                </div>
            </div>
        </div>
    </div>
@endsection
