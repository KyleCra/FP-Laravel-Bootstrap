@extends('templates.main')

@section('body')
<div class="page-header p-4 pb-0 mt-4">
        <h1>Create Inventory</h1>
        <form id="create-inventory-form" action="{{ route('inventory.store') }}" method="POST">
        @csrf
        @method('POST')
        <div class="row">

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Product Name:</strong>
                    <input type="text" name="Product Name" value="" class="form-control" placeholder="Product Name">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Category:</strong>
                    <select  class="form-control" name="Category" >
                    @foreach ($categories as $item )
                        <option value="{{$item->id}}">{{$item->name }}</option>
                    @endforeach
                    </select>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Stock:</strong>
                    <input type="text" name="Stock" value="" class="form-control" placeholder="Stock">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Price:</strong>
                    <input type="text" name="Price" value="" class="form-control" placeholder="Price">
                </div>
            </div>
        </div>
        <button id="create-inventory-form" class="btn btn-primary " value="submits">Submit</button>
    </form>
</div>

<!-- Add this to the head section of your HTML document -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<!-- Your corrected JavaScript code -->
<script>
    $(document)

    $(document).on('submit', '#create-inventory-form', function (e) {
        e.preventDefault();
        let formData = $(this).serialize();

        $.ajax({
    url: $(this).attr('action'),
    method: 'POST',
    data: formData
}).then(response => {
   // Remove this line if you don't need the alert

        window.location.href ="/inventory";
});
    });
    function sendData() {
	$.ajax({
		url: '/chart/barang_per_kategori'
	}).then (res => {
	});
}

</script>


@endsection
