<html>
    <body>
        <h1>Selamat datang , {{ $name }}</h1>
    </body>
</html>
