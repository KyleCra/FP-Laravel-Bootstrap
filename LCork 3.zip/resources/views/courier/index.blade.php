@extends('templates.main')

@section('body')
    <div class="page-header p-4 pb-0 mt-4">
        <h1>List Courier</h1>

        <div class="table-responsive">

        <table class="table">
        <thead>
            <tr>
                <th scope="col" width="5%">
                    <div class="form-check form-check-primary">
                        <input class="form-check-input" id="custom_mixed_parent_all" type="checkbox">
                    </div>
                </th>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">ACTION</th>
            </tr>
            <tr aria-hidden="true" class="mt-3 d-block table-row-hidden"></tr>
        </thead>
        <tbody>
            @foreach($courier as $item)
                <tr>
                    <td></td>
                    <td>{{$item->id}}</td>
                    <td>{{$item->name}}</td>

                    <td>
                        <form action="{{ route('courier.destroy',$item->id) }}" method="POST">
                        <a class="btn btn-info" href="{{route('courier.show',$item->id)}}">Show</a>
                        <a class="btn btn-primary" href="{{route('courier.edit',$item->id)}}">Edit</a>

                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>

                </tr>
            @endforeach
        </tbody>
    </table>
    <a class="btn btn-primary" href="{{route('courier.create')}}">Create Courier</a>
    <br/>
	Halaman : {{ $courier->currentPage() }} <br/>
	Jumlah Data : {{ $courier->total() }} <br/>
	Data Per Halaman : {{ $courier->perPage() }} <br/>

    <br/>
	{{ $courier->links() }}
    </div>
@endsection
