@extends('templates.main')

@section('body')
    <div class="page-header p-4 pb-0 mt-4">
        <h1>List Orders</h1>

        <div class="table-responsive">

        <table class="table">
        <thead>
            <tr>
                <th scope="col" width="5%">
                    <div class="form-check form-check-primary">
                        <input class="form-check-input" id="custom_mixed_parent_all" type="checkbox">
                    </div>
                </th>
                <th scope="col">ID</th>
                <th scope="col">Customer Name</th>
                <th scope="col">Courier Name</th>
                <th scope="col">Status Payment</th>
                <th scope="col">Status Delivery</th>
                <th scope="col">ACTION</th>
            </tr>
            <tr aria-hidden="true" class="mt-3 d-block table-row-hidden"></tr>
        </thead>
        <tbody>
            @foreach($orders as $item)
                <tr>
                    <td></td>
                    <td>{{$item->id}}</td>
                    <td>{{$item->Customer}}</td>
                    <td>{{$item->Courier}}</td>
                    <td>{{$item->payment_status}}</td>
                    <td>{{$item->delivery_status}}</td>

                    <td>
                        <form action="{{ route('order.destroy', $item->id) }}" method="POST" class="d-inline">
                        @csrf
                        @method('DELETE')
@if($item->delivery_status!="paid")
<a class="btn btn-primary" href="{{route('order.edit',$item->id)}}">Edit</a>

@endif
                        <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">delete</button>
                    </form>

                    </td>

                </tr>
            @endforeach
        </tbody>
    </table>
    <a class="btn btn-primary" href="{{route('order.create')}}">Create Order</a>
    <br/>
	{{--Halaman : {{ $orders->currentPage() }} <br/>
	Jumlah Data : {{ $orders->total() }} <br/>
	Data Per Halaman : {{ $orders->perPage() }} <br/>--}}

    <br/>
	{{-- $orders->links() --}}
    </div>
@endsection
