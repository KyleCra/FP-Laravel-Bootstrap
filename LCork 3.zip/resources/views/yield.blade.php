@extends('welcome')
@section('content')

Memunculkan daftar kategori {{$varA}}<br>
Daftar kategori file




@endsection
{{-- Jadi fungsi dari @yield ini untuk menghubungkan section --}}








