<h3><a href="">{{ $post['title'] }}</a></h3>

<div class="mb-3">
    <p>{{ $post['content'] }}</p>
    <a href="" class="btn btn-primary">Edit Post</a>
</div>
