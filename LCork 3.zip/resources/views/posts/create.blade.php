@extends('layouts.app')
@section('title','Create The Post')

@section('content')
<form action="" method="POST">
    @csrf
    @include('posts.partials.form')
    <div><input type="submit" value="Create Post" class="btn btn-primary btn-block"></div>
@endsection
