<?php
$posts = [
    1 => [
      'id' => 1,
      'title' => 'Intro to Laravel',
      'content' => 'This is a short intro to Laravel',
      'is_new' => true,
      'has_comments' => true
    ],
    2 => [
      'id' => 2,
      'title' => 'Intro to PHP',
      'content' => 'This is a short intro to PHP',
      'is_new' => false
    ],
    3 => [
      'id' => 3,
      'title' => 'Intro to Golang',
      'content' => 'This is a short intro to Golang',
      'is_new' => false
    ]
  ];
?>

@extends('layouts.app')

@section('title', 'Lists Posts')

@section('content')
{{-- @each('posts.partials.post', $posts, 'post') --}}
@forelse ($posts as $key => $post)
  @include('posts.partials.post', [])
@empty
No posts found!
@endforelse

@endsection
