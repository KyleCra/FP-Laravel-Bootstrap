@extends('templates.main')

@section('body')
    <div class="page-header p-4 pb-0 mt-4">
        <h1>List Customers</h1>

        <div class="table-responsive">

        <table class="table">
        <thead>
            <tr>
                <th scope="col" width="5%">
                    <div class="form-check form-check-primary">
                        <input class="form-check-input" id="custom_mixed_parent_all" type="checkbox">
                    </div>
                </th>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Image</th>
                <th scope="col">Address</th>
                <th scope="col">Telp</th>
                <th scope="col">ACTION</th>
            </tr>
            <tr aria-hidden="true" class="mt-3 d-block table-row-hidden"></tr>
        </thead>
        <tbody>
            @foreach($customers as $item)
                <tr>
                    <td></td>
                    <td>{{$item->id}}</td>
                    <td>{{$item->name}}</td>
                    <td>{{$item->image}}</td>
                    <td>{{$item->address}}</td>
                    <td>{{$item->telp}}</td>

                    <td>
                        <form action="{{ route('customer.destroy',$item->id) }}" method="POST">
                        <a class="btn btn-info" href="{{route('customer.show',$item->id)}}">Show</a>
                        <a class="btn btn-primary" href="{{route('customer.edit',$item->id)}}">Edit</a>

                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>

                </tr>
            @endforeach
        </tbody>
    </table>
    <a class="btn btn-primary" href="{{route('customer.create')}}">Create Customer</a>
    <br/>
	Halaman : {{ $customers->currentPage() }} <br/>
	Jumlah Data : {{ $customers->total() }} <br/>
	Data Per Halaman : {{ $customers->perPage() }} <br/>

    <br/>
	{{ $customers->links() }}
    </div>
@endsection
