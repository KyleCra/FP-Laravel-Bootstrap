@extends('templates.main')

@section('body')
<div class="page-header p-4 pb-0 mt-4">
        <h1>Create Customer</h1>
        <form id="create-customer-form" action="{{ route('customer.store') }}" method="POST">
        @csrf
        @method('POST')
        <div class="row">

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Name:</strong>
                    <input type="text" name="Name" value="" class="form-control" placeholder="Name">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Address:</strong>
                    <input type="text" name="Address" value="" class="form-control" placeholder="Address">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Telp</strong>
                    <input type="text" name="Telp" value="" class="form-control" placeholder="Telp">
                </div>
            </div>
        </div>
        <button id="create-inventory-form" class="btn btn-primary " value="submits">Submit</button>
    </form>
</div>

<!-- Add this to the head section of your HTML document -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<!-- Your corrected JavaScript code -->
<script>
    $(document)

    $(document).on('submit', '#create-inventory-form', function (e) {
        e.preventDefault();
        let formData = $(this).serialize();

        $.ajax({
    url: $(this).attr('action'),
    method: 'POST',
    data: formData
}).then(response => {
   // Remove this line if you don't need the alert

        window.location.href ="/inventory";
});
    });
    function sendData() {
	$.ajax({
		url: '/chart/barang_per_kategori'
	}).then (res => {
	});
}

</script>


@endsection
