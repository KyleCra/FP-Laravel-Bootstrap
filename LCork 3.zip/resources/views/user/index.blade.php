@extends('templates.main')

@section('body')
    <div class="page-header p-4 pb-0 mt-4">
        <h1>List User</h1>

        <div class="table-responsive">

        <table class="table">
        <thead>
            <tr>
                <th scope="col" width="5%">
                    <div class="form-check form-check-primary">
                        <input class="form-check-input" id="custom_mixed_parent_all" type="checkbox">
                    </div>
                </th>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th class="text-center" scope="col">EMAIL</th>
                <th scope="col">ACTION</th>
            </tr>
            <tr aria-hidden="true" class="mt-3 d-block table-row-hidden"></tr>
        </thead>
        <tbody>
            @foreach($users as $user)
                <tr>
                    <td></td>
                    <td>{{$user->id}}</td>
                    <td>{{$user->name}}</td>
                    <td>{{$user->email}}</td>
                    <td>
                        <form action="{{ route('user.destroy',$user->id) }}" method="POST">
                        <a class="btn btn-info" href="{{route('user.show',$user->id)}}">Show</a>
                        <a class="btn btn-primary" href="{{route('user.edit',$user->id)}}">Edit</a>

                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>

                </tr>
            @endforeach
        </tbody>
    </table>
    <a class="btn btn-primary" href="{{route('user.create')}}">Create User</a>
    <br/>
	Halaman : {{ $users->currentPage() }} <br/>
	Jumlah Data : {{ $users->total() }} <br/>
	Data Per Halaman : {{ $users->perPage() }} <br/>

    <br/>
	{{ $users->links() }}
    </div>
@endsection
