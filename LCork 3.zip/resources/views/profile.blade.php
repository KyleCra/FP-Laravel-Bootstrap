@extends('templates.main')
@section('body')

<div class="page-header p-4 pb-0 mt-4 row">
    @include('posts.card',['name' => 'John Doe'])
    {{-- @include('profile-form') --}}
</div>

@endsection
