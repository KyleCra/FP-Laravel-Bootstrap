<?php
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\InventoryController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\CourierController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\AuthController;
// use App\Http\Controllers\LoginController;
use App\Models\User;

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController;
// Route::get('/greeting', function () {
//     return view('greeting', ['name' => 'Doni Sudonoo']);
// });
// Route::get('/welcome', function () {
//     return 'Selamat Datang';
// });
// Route::get('/myarray', function () {
//     return [1, 2, 3];
// });
Route::get('/', function () {
    return view('user.loginn');
});
// Route::get('/profile', function () {
//     return view('profile');
// });
// Route::get('/posts', function () {
//     return view('posts.list');
// });

//Laravel-Controllers

Route::get('/home', [HomeController::class, 'home'])
->name('home.index');
Route::get('/contact', [HomeController::class, 'contact'])
->name('home.contact');
Route::get('/create', [HomeController::class, 'create']);

Route::get('/store', [HomeController::class, 'store']);
Route::post('/register', [HomeController::class, 'register']);
Route::get('/myjson', [HomeController::class, 'myjson']);

// Route::put('/user/{id}', [UserController::class, 'update']);
// /Redirect response adalah turunan dari kelas Illuminate\Http\RedirectResponse, dan berisi header yang mengarahkan pengguna ke URL lain.
//Ada beberapa cara untuk menghasilkan instance RedirectResponse. Metode paling sederhana adalah dengan menggunakan global redirect helper:
Route::get('/mypage', function () {
    return redirect('/');
});


//articles
Route::get('/articles', [ArticleController::class, 'index']);

Route::resource('user', UserController::class);
// Route::resource('login', LoginController::class);

Route::post('/login', [AuthController::class, 'loginUser'])->name('login');
//inventory
Route::resource('inventory', InventoryController::class);


Route::resource('category', CategoryController::class);

Route::resource('customer', CustomerController::class);

Route::resource('courier', CourierController::class);

Route::resource('order', OrderController::class);
