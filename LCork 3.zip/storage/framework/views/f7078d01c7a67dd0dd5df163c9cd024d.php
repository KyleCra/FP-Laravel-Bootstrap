<?php $__env->startSection('body'); ?>
    <div class="page-header p-4 pb-0 mt-4">
        <h1>List Courier</h1>

        <div class="table-responsive">

        <table class="table">
        <thead>
            <tr>
                <th scope="col" width="5%">
                    <div class="form-check form-check-primary">
                        <input class="form-check-input" id="custom_mixed_parent_all" type="checkbox">
                    </div>
                </th>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">ACTION</th>
            </tr>
            <tr aria-hidden="true" class="mt-3 d-block table-row-hidden"></tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $courier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td></td>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->name); ?></td>

                    <td>
                        <form action="<?php echo e(route('courier.destroy',$item->id)); ?>" method="POST">
                        <a class="btn btn-info" href="<?php echo e(route('courier.show',$item->id)); ?>">Show</a>
                        <a class="btn btn-primary" href="<?php echo e(route('courier.edit',$item->id)); ?>">Edit</a>

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <a class="btn btn-primary" href="<?php echo e(route('courier.create')); ?>">Create Courier</a>
    <br/>
	Halaman : <?php echo e($courier->currentPage()); ?> <br/>
	Jumlah Data : <?php echo e($courier->total()); ?> <br/>
	Data Per Halaman : <?php echo e($courier->perPage()); ?> <br/>

    <br/>
	<?php echo e($courier->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\Laravel & Bootstrap\Kursus 15. Sabtu 20 Jan-24 Feb 2024\LAravel\Templates Cork\resources\views/courier/index.blade.php ENDPATH**/ ?>