<?php $__env->startSection('body'); ?>
    <div class="page-header p-4 pb-0 mt-4">
        <h1>List Orders</h1>

        <div class="table-responsive">

        <table class="table">
        <thead>
            <tr>
                <th scope="col" width="5%">
                    <div class="form-check form-check-primary">
                        <input class="form-check-input" id="custom_mixed_parent_all" type="checkbox">
                    </div>
                </th>
                <th scope="col">ID</th>
                <th scope="col">Customer Name</th>
                <th scope="col">Courier Name</th>
                <th scope="col">Status Payment</th>
                <th scope="col">Status Delivery</th>
                <th scope="col">ACTION</th>
            </tr>
            <tr aria-hidden="true" class="mt-3 d-block table-row-hidden"></tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td></td>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->Customer); ?></td>
                    <td><?php echo e($item->Courier); ?></td>
                    <td><?php echo e($item->payment_status); ?></td>
                    <td><?php echo e($item->delivery_status); ?></td>

                    <td>
                        <form action="<?php echo e(route('order.destroy', $item->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
<?php if($item->delivery_status!="paid"): ?>
<a class="btn btn-primary" href="<?php echo e(route('order.edit',$item->id)); ?>">Edit</a>

<?php endif; ?>
                        <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">delete</button>
                    </form>

                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <a class="btn btn-primary" href="<?php echo e(route('order.create')); ?>">Create Order</a>
    <br/>
	

    <br/>
	
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\Laravel & Bootstrap\Kursus 15. Sabtu 20 Jan-24 Feb 2024\LAravel\Templates Cork\resources\views/order/index.blade.php ENDPATH**/ ?>