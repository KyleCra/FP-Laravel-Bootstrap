<?php $__env->startSection('body'); ?>
    <div class="page-header p-4 pb-0 mt-4">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <h2>Show category</h2>
            </div>
            <div class="pull-right">
                <a href="<?php echo e(route('category.index')); ?>" class="btn btn-primary">Back</a>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                <strong>Name:</strong>
                <?php echo e($category->name); ?>

                </div>
            </div>
           
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\Laravel & Bootstrap\Kursus 15. Sabtu 20 Jan-24 Feb 2024\LAravel\Templates Cork\resources\views/category/show.blade.php ENDPATH**/ ?>