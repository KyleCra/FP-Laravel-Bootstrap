<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>

<?php for($i = 0; $i < 10; $i++): ?>
    The current value is <?php echo e($i); ?> <br>
<?php endfor; ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/LAravel/Templates Cork/resources/views/home/index.blade.php ENDPATH**/ ?>