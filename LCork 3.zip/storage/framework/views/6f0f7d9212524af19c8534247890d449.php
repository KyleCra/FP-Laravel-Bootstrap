<?php $__env->startSection('body'); ?>
    <div class="page-header p-4 pb-0 mt-4">
        <h1>Inventory</h1>

        <div class="table-responsive">

        <table class="table">
        <thead>
            <tr>
                <th scope="col" width="5%">
                    <div class="form-check form-check-primary">
                        <input class="form-check-input" id="custom_mixed_parent_all" type="checkbox">
                    </div>
                </th>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Image</th>
                <th scope="col">Category</th>
                <th scope="col">Stok</th>
                <th>Price</th>
                <th scope="col">Action</th>
            </tr>
            <tr aria-hidden="true" class="mt-3 d-block table-row-hidden"></tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td></td>
                    <td><?php echo e($inventory->id); ?></td>
                    <td><?php echo e($inventory->name); ?></td>
                    <td><img src="<?php echo e(asset('$inventory->image')); ?>"></td>
                    <td><?php echo e($inventory->category_name); ?></td>
                    <td><?php echo e($inventory->stock); ?></td>
<td><?php echo e($inventory->price); ?></td>
                    <td>
                        <form action="<?php echo e(route('inventory.destroy',$inventory->id)); ?>" method="POST">
                        <a class="btn btn-info" href="<?php echo e(route('inventory.show',$inventory->id)); ?>">Show</a>
                        <a class="btn btn-primary" href="<?php echo e(route('inventory.edit',$inventory->id)); ?>">Edit</a>

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <a class="btn btn-primary" href="<?php echo e(route('inventory.create')); ?>">Create Inventory</a>
    <br/>
	Halaman : <?php echo e($inventories->currentPage()); ?> <br/>
	Jumlah Data : <?php echo e($inventories->total()); ?> <br/>
	Data Per Halaman : <?php echo e($inventories->perPage()); ?> <br/>

    <br/>
	<?php echo e($inventories->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/LAravel/Templates Cork/resources/views/inventory/index.blade.php ENDPATH**/ ?>