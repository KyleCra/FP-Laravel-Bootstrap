<h3><a href=""><?php echo e($post['title']); ?></a></h3>

<div class="mb-3">
    <p><?php echo e($post['content']); ?></p>
    <a href="" class="btn btn-primary">Edit Post</a>
</div>
<?php /**PATH C:\xampp\htdocs\wfp\Templates Cork\resources\views/posts/partials/post.blade.php ENDPATH**/ ?>