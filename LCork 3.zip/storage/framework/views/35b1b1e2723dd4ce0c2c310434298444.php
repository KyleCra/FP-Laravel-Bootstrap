<?php $__env->startSection('body'); ?>
<div id="product">
	<?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="product row mb-4">
			<div class="col-sm-5">
				<label>Product</label>
				<select type="number" class="form-control product-input" name= "product []" value="" required>
					<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value=" (( Sproduct->id 3)" <?php if($product->id == $item->inventory_id): ?> selected <?php endif; ?>><?php echo e($product->name); ?> - Rp. <?php echo e(number_format ($product->price)); ?> </option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="col-sm-3">
				<label>Quantity</label>
				<input type="number" class="form-control quantity-input" name="quantity []" value="({ $item->quantity }" required>
			</div>
			<div class="col-sm-3">
				<label>Total</label>
				<h6 class="total-input mt-3"></h6>
			</div>
			<div class="col-sm-1">
				<label class="text-white">Action</label>
				<button class="btn btn-danger delete-product">delete</button>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- Add this to the head section of your HTML document -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<!-- Your corrected JavaScript code -->
<script>
    $(document)
        .on('click', ".delete-product", function () {
            $(this).closest('.product').remove();
        })
        .on('click', '#add-product', function () {
            let product_html = $('.product').eq(0).html();
            $('#product').append(`<div class='product row mb-4'>${product_html}</div>`);
        })
        .on("change", ".product-input", function () {
            let product = $(this).closest('.product');
            updateTotal(product);
        })
        .on('keyup', '.quantity-input', function () {
            let product = $(this).closest(".product");
            updateTotal(product);
        });

    function updateTotal(product) {
        let price = product.find('option:selected').html().split('Rp. ')[1].replaceAll(',', '');
        let qty = product.find('.quantity-input').val();
        product.find('.total-input').html('Rp.' + (price * qty).toLocaleString());
    }

    $(document).on('submit', '#create-order-form', function (e) {
        e.preventDefault();
        let formData = $(this).serialize();

        $.ajax({
    url: $(this).attr('action'),
    method: 'POST',
    data: formData
}).then(response => {
   // Remove this line if you don't need the alert

    if (response.status) {
        // toastr.success(response.message);
  alert(response);
        // Redirect to the order.index route
        window.location.href ="/order";
    } else {
        toastr.error(response.message);
    }
});
    });
    function sendData() {
	$.ajax({
		url: '/chart/barang_per_kategori'
	}).then (res => {
	});
}

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\Laravel & Bootstrap\Kursus 15. Sabtu 20 Jan-24 Feb 2024\LAravel\Templates Cork\resources\views/order/edit.blade.php ENDPATH**/ ?>