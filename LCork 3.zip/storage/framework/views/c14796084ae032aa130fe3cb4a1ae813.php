<?php $__env->startSection('body'); ?>

<div class="page-header p-4 pb-0 mt-4 row">
    <?php echo $__env->make('posts.card',['name' => 'John Doe'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wfp\Templates Cork\resources\views/profile.blade.php ENDPATH**/ ?>