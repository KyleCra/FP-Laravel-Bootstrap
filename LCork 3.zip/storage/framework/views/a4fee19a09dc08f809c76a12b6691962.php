<?php $__env->startSection('content'); ?>

Memunculkan daftar kategori <?php echo e($varA); ?><br>
Daftar kategori file




<?php $__env->stopSection(); ?>










<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\Laravel & Bootstrap\Kursus 3. Sabtu 23 September 2023\View & Templates Assign\resources\views/yield.blade.php ENDPATH**/ ?>