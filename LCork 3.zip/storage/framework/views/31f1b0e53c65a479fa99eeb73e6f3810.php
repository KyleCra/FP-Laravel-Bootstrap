<?php $__env->startSection('body'); ?>
<div class="page-header p-4 pb-0 mt-4">
        <h1>Create courier</h1>
        <form id="create-courier-form" action="<?php echo e(route('courier.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <div class="row">

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Name:</strong>
                    <input type="text" name="Name" value="" class="form-control" placeholder="Name">
                </div>
            </div>

        </div>
        <button id="create-courier-form" class="btn btn-primary " value="submits">Submit</button>
    </form>
</div>

<!-- Add this to the head section of your HTML document -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<!-- Your corrected JavaScript code -->
<script>
    $(document)

    $(document).on('submit', '#create-courier-form', function (e) {
        e.preventDefault();
        let formData = $(this).serialize();

        $.ajax({
    url: $(this).attr('action'),
    method: 'POST',
    data: formData
}).then(response => {
   // Remove this line if you don't need the alert

        window.location.href ="/courier";
});
    });
    function sendData() {
	$.ajax({
		url: '/chart/barang_per_kategori'
	}).then (res => {
	});
}

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming\Laravel & Bootstrap\Kursus 15. Sabtu 20 Jan-24 Feb 2024\LAravel\Templates Cork\resources\views/courier/create.blade.php ENDPATH**/ ?>