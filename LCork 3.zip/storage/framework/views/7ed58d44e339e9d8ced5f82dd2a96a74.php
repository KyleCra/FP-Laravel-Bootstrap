<?php $__env->startSection('body'); ?>
    <div class="page-header p-4 pb-0 mt-4">
        <h1>List User</h1>

        <div class="table-responsive">

        <table class="table">
        <thead>
            <tr>
                <th scope="col" width="5%">
                    <div class="form-check form-check-primary">
                        <input class="form-check-input" id="custom_mixed_parent_all" type="checkbox">
                    </div>
                </th>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th class="text-center" scope="col">EMAIL</th>
                <th scope="col">ACTION</th>
            </tr>
            <tr aria-hidden="true" class="mt-3 d-block table-row-hidden"></tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td></td>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <form action="<?php echo e(route('user.destroy',$user->id)); ?>" method="POST">
                        <a class="btn btn-info" href="<?php echo e(route('user.show',$user->id)); ?>">Show</a>
                        <a class="btn btn-primary" href="<?php echo e(route('user.edit',$user->id)); ?>">Edit</a>

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br/>
	Halaman : <?php echo e($users->currentPage()); ?> <br/>
	Jumlah Data : <?php echo e($users->total()); ?> <br/>
	Data Per Halaman : <?php echo e($users->perPage()); ?> <br/>

    <br/>
	<?php echo e($users->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wfp\Templates Cork\resources\views/user/index.blade.php ENDPATH**/ ?>