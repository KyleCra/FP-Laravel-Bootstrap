<?php

namespace App\Http\Controllers;
use App\Models\Inventory;
use App\Models\Category;
use Illuminate\Http\Request;

class InventoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $inventories = Inventory::join('categories', 'inventories.category_id', '=', 'categories.id')
            ->select('inventories.*', 'categories.name as category_name')
            ->paginate(10);

        return view('inventory.index', compact('inventories'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories=Category::select('*')->get();
        return view('inventory.create',['categories' => $categories]);

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // dd($request->all());
        $inventory = Inventory::create([

            'name'=>$request->Product_Name,
            'category_id'=>$request->Category,
            'stock'=>$request->Stock,
            'price'=>$request->Price,
            ]);
            $inventories = Inventory::join('categories', 'inventories.category_id', '=', 'categories.id')
            ->select('inventories.*', 'categories.name as category_name')
            ->paginate(10);
// dd("halo)");
        return view('inventory.index', compact('inventories'));

    }

    /**
     * Display the specified resource.
     */
    public function show(Inventory $inventory)
    {
        $category_name=Category::where('id',$inventory->category_id)->first()->name;
        return view('inventory.show', compact('inventory','category_name'));
    }


    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Inventory $inventory)
    {
        $categories=Category::all();
        return view('inventory.edit', compact('inventory','categories'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Inventory $inventory)
    {
        $request->validate([
            'name'=>'required',
            'category_id'=>'required',
            'stock'=>'required',
            'price'=>'required',
        ]);

        $inventory->update($request->all());

        return redirect()->route('inventory.index')
            ->with('success','Inventory updated successfully');
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
// dd($id);
$inventories=Inventory::select('*')->where('id',$id);
        $inventories->delete();
        // dd($inventories);
        return redirect()->route('inventory.index')
            ->with('success','Inventory deleted successfully');
    }
}
