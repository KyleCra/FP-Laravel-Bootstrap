<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        $users = User::paginate(5);

        return view('user.index',['users' => $users]);
    }

    public function login(Request $request)
    {
        dd($request);
        $user->login();
        return redirect()->route('user.login')
        ->with('Login Successfully');
        return view('user.index',['users' => $users]);

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // $categories=Category::select('*')->get(); ** User tidak perlu create. Hanya jika ada category_id di tabel nya
        return view('user.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $user = User::create([
            'name'=>$request->Name,
            'email'=>$request->Email,
            'password'=>$request->Password,
            ]);
            $users = User::paginate(5);
            return view('user.index',['users' => $users]);

    }

    /**
     * Display the specified resource.
     */
    public function show(User $user)
    {
        return view('user.show',compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user)
    {
        return view('user.edit',compact('user'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, User $user)
    {
        $request->validate([
            'name'=>'required',
            'email'=>'required',
        ]);
        $user->update($request->all());
        return redirect()->route('user.index')
                        ->with('success','User Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(User $user)
    {
        // dd("sfs:");
        $user->delete();
        return redirect()->route('user.index')
        ->with('success','User Deleted Successfully');

    }

}
