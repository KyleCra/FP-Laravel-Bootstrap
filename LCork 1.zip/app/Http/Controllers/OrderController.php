<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\Customer;
use App\Models\Courier;
use App\Models\Inventory;
use App\Models\OrderItem;
use DB;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $orders = Order::select('orders.id','customers.name as Customer','couriers.name as Courier','orders.payment_status','orders.delivery_status')
        ->join('customers','customers.id','orders.customer_id')
        ->join('couriers','couriers.id','orders.courier_id')
        ->get();
        //dd($orders);
        return view('order.index',['orders' => $orders]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $customers=Customer::select('*')->get();
        $couriers=Courier::select('*')->get();
        $products=Inventory::select('*')->get();
        return view('order.create',['customers' => $customers,'couriers'=>$couriers,'products'=>$products]);

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
    //    dd($request);

        $order = Order::create([
        "customer_id" => $request->customer,
        "courier_id" => $request->courier,
        "payment_status" => 'unpaid',
        "delivery_status" => 'pickup',
        ]);
        for ($i=0;$i<count($request->product);$i++) {
            OrderItem::create([
                'order_id' => $order->id,
                'inventory_id' => $request->product[$i],
                'quantity' => $request->quantity[$i]
            ]);

            $product = Inventory::find($request->product [$i]);
            if ($product->stock < $request->quantity[$i]) {
                DB::rollback();
                return redirect ()
                    ->back()
                    ->with('error', "Only $product->stock remaining stock of product $product->name")
                    ->withInput();
            }

            $product->stock =$product->stock- $request->quantity[$i];
            $product->save();
            // dd("done");
        }

        return redirect()
        ->route('order.index')
        ->with('success','Success create order');
    }

    /**
     * Display the specified resource.
     */
    public function show(order $order)
    {
        return view('order.show',compact('order'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
{
	$order = Order::find($id);









$orderss= DB::select('select * from orders o inner join order_items oi on oi.order_id=o.id where o.id=?', [$id]);
$items = OrderItem::where('order_id',$id)->get();
// dd($items);
	if ($order->payment_status == 'paid') {
		return redirect ()->back()->with('error', 'Payment status this order is paid, you can\'t edit this order');
	}

	$customers = Customer:: all();
	$couriers = Courier::all();
	$inventories = Inventory:: all();

	return view('order.edit', [
		'title' => 'Edit Order',
		'order' => $orderss,
		'customers' => $customers,
		'couriers' => $couriers,
		'products' => $inventories,
'order_items'=>$items,
	]);
}

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validator = Validator::make($request->all(), [
            'customer_id' => ['required', 'numeric'],
            'courier_id' => ['required', 'numeric'],
            'product' => ['required', 'array', 'min:1'],
            'quantity' => ['required', 'array', 'min:1'],
        ]);

        if ($validator->fails()) {
            return redirect()
                ->back()
                ->with('error', $validator->errors()->first());
        }

        DB::beginTransaction();

        $order = Order::find($id)->update([
            'customer_id' => $request->customer_id,
            'courier_id' => $request->courier_id,
            'payment_status' => 'unpaid',
            'delivery_status' => 'pickup',
        ]);

        $already_add = [];

        for ($i = 0; $i < count($request->product); $i++) {
            OrderItem::create([
                'order_id' => $order->id,
                'inventory_id' => $request->product[$i],
                'quantity' => $request->quantity[$i],
            ]);

            $product = Inventory::find($request->product[$i]);

            if ($product->stock < $request->quantity[$i]) {
                DB::rollback();
                return response()->json([
                    'status' => false,
                    'message' => "Only $product->stock remaining stock of product $product->name",
                ]);
            }

            if (in_array($request->product[$i], $already_add)) {
                DB::rollback();
                return response()->json([
                    'status' => false,
                    'message' => "Please select a different product. $product->name has more than 1",
                ]);
            }

            $product->stock -= $request->quantity[$i];
            $product->save();
            $already_add[] = $request->product[$i];
        }

        DB::commit();

        return response()->json([
            'status' => true,
            'message' => 'Order updated successfully.',
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Order $Order)
    {
        $Order->delete();

        return redirect()->route('order.index')
            ->with('success','Order deleted successfully');
    }

}
