<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function home()
    {
      return view('home.index');
    }

    public function contact()
    {
      return view('home.contact');
    }
    public function store(Request $request)
    {
        $this->validate($request,[
            'name'=>['required|min:3|max:20'],
            'username'=>['required|min:5|max:20'],
            'password'=>['required|min:8|max:20']
          ]);
      $path=$request->path();
      echo 'Path Method: '.$path;
        echo '<br>';
    $url=$request->url();
    echo 'URL method: '.$url;
    }
    public function create()
    {
      return view('home.create');
    }
    public function register(Request  $request)
    {

        $this->validate($request,[
          'name'=>['required|min:3|max:20'],
          'username'=>['required|min:5|max:20'],
          'password'=>['required|min:8|max:20']
        ]);

       $name = $request->input('name');
       echo 'Name: '.$name;
       echo '<br>';

       $username = $request->username;
       echo 'Username: '.$username;
       echo '<br>';

       $password = $request->password;
       echo 'Password: '.$password;

    }
    public function myjson()
    {
    return response()->json(['name' => 'Johny D', 'city' => 'Surabaya']);
    }
}
